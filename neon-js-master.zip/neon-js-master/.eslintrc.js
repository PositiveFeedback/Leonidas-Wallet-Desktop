module.exports = {
    "extends": "standard",
    "env": {
        "mocha": true
    }
};